package com.qf.service.impl;

import java.util.List;

import com.qf.dao.CartDao;
import com.qf.dao.impl.CartDaoImpl;
import com.qf.entry.BuyGoods;
import com.qf.entry.Cart;
import com.qf.service.CartService;

public class CartServiceImpl implements CartService{
	CartDao dao = new CartDaoImpl();
	@Override
	public boolean add(Cart cart) {
		// TODO Auto-generated method stub
		return dao.add(cart);
	}
	@Override
	public List<BuyGoods> getAll(int uid) {
		// TODO Auto-generated method stub
		return dao.getAll(uid);
	}
	@Override
	public boolean update(Cart cart) {
		// TODO Auto-generated method stub
		return dao.update(cart);
	}
	@Override
	public boolean delete(int uid, int pid) {
		// TODO Auto-generated method stub
		return dao.delete(uid, pid);
	}

}
