package com.qf.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.ResultSetHandler;
import org.apache.commons.dbutils.handlers.BeanHandler;

import com.qf.dao.CartDao;
import com.qf.entry.BuyGoods;
import com.qf.entry.Cart;
import com.qf.entry.Goods;
import com.qf.util.C3P0Utils;

public class CartDaoImpl implements CartDao {
	QueryRunner qr = new QueryRunner(C3P0Utils.getDataSource());

	@Override
	public boolean add(Cart cart) {
		// ���ӹ��ﳵ��Ϊ����
		// 1.��һ������insert
		// 2.���Ӷ�� update ����+1 ��Ǯ ԭ�б��еļ۸�+�µļ۸�
		// �Ȳ�ѯtb_cart�����Ƿ��Ѿ��и�����¼
		try {
			Cart c = qr.query("select * from tb_cart where id=? and pid=?", new BeanHandler<Cart>(Cart.class),
					cart.getUid(), cart.getPid());
			int i = 0;
			if (c == null) {
				i = qr.update("insert into tb_cart(id,pid,num,money) values(?,?,?,?)",
						new Object[] { cart.getUid(), cart.getPid(), cart.getNum(), cart.getMoney() });
			} else {
				i = qr.update("update tb_cart set num=num+1,money=? where id=? and pid=?",
						c.getMoney() + cart.getMoney(), cart.getUid(), cart.getPid());
			}
			if (i > 0) {
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public List<BuyGoods> getAll(int uid) {
		String sql = "select g.*,c.num,c.money from tb_cart c join tb_goods g on g.id = c.pid where c.id=?";
		
		try {
			List<BuyGoods> list = qr.query(sql, new ResultSetHandler<List<BuyGoods>>() {

				@Override
				public List<BuyGoods> handle(ResultSet arg0) throws SQLException {
					List<BuyGoods> list = new ArrayList<>();
					while(arg0.next()){
						list.add(new BuyGoods(arg0.getInt("num"), arg0.getInt("money"), 
								new Goods(arg0.getInt("id"), arg0.getString("name"), 
										arg0.getString("pubdate"), arg0.getString("picture"),
										arg0.getInt("price"), arg0.getInt("star"),
										arg0.getString("intro"), arg0.getInt("typeid"), "")
								));
					}
					return list;
				}
				
			}, uid);
			if(list!=null){
				return list;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	//�����ı� ���۸��Ÿı�
	@Override
	public boolean update(Cart cart) {
		String sql = "update tb_cart set num=num+?,money=money+? where id=? and pid=?";
		try {
			int res = qr.update(sql,cart.getNum(),cart.getNum()>0?cart.getMoney():-cart.getMoney(),cart.getUid(),cart.getPid());
			if(res>0){
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	//һ������ ��� ɾ��һ�� / ��չ��ﳵ �� pid>0��ʱ�� ���� ���� uid ��pidȥɾ��һ��
	//û��pid ������չ��ﳵ
	@Override
	public boolean delete(int uid, int pid) {
		String sql = "delete from tb_cart where id=?";
		if(pid>0){
			sql += " and pid="+pid;
		}
		try {
			int res = qr.update(sql,uid);
			if(res>0){
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

}
