package com.qf.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

@WebFilter("/*")
public class AutoLoginFilter implements Filter{

	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void doFilter(ServletRequest arg0, ServletResponse arg1, FilterChain arg2)
			throws IOException, ServletException {
		// TODO Auto-generated method stub
		HttpServletRequest request = (HttpServletRequest) arg0;
		String uri = request.getRequestURI();
		//��uri ��ַ ������admin(��̨) ���ҽ���login.jspʱ
		if(!uri.contains("admin") && uri.endsWith("login.jsp")){
			//��ȡcookie
			String username = "";
			String password = "";
			Cookie[] cookies = request.getCookies();
			if(cookies!=null){
				for(Cookie cookie:cookies){
					if("autoUser".equals(cookie.getName())){
						String[] str = cookie.getValue().split(":");
						username = str[0];
						password = str[1];
						System.out.println(username+"::"+password);
						break;
					}
				}
			}
			if(username.length()>0){
				request.setAttribute("username", username);
				request.setAttribute("password", password);
				request.setAttribute("byfilter", "�Զ���¼");
				request.getRequestDispatcher("userLogin").forward(request, arg1);
			}else{
				arg2.doFilter(request, arg1);
			}
		}else{
			arg2.doFilter(request, arg1);
		}
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		// TODO Auto-generated method stub
		
	}
	
}
