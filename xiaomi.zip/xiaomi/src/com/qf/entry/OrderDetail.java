package com.qf.entry;

import java.util.List;

public class OrderDetail {
	//��Ŷ�����ϸ��Ϣ ʵ��
	//���� ����order�� address�� orderdetail��goods��ͨ��pid������ȡ��������
	private Order order;
	private Address address;
	private List<BuyGoods> list;
	public OrderDetail() {
		super();
	}
	public OrderDetail(Order order, Address address, List<BuyGoods> list) {
		super();
		this.order = order;
		this.address = address;
		this.list = list;
	}
	public Order getOrder() {
		return order;
	}
	public void setOrder(Order order) {
		this.order = order;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public List<BuyGoods> getList() {
		return list;
	}
	public void setList(List<BuyGoods> list) {
		this.list = list;
	}
	@Override
	public String toString() {
		return "OrderDetail [order=" + order + ", address=" + address + ", list=" + list + "]";
	}
	
}
