package com.qf.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.qf.entry.Address;
import com.qf.entry.User;
import com.qf.service.UserService;
import com.qf.service.impl.UserServiceImpl;
@WebServlet("/userAddress")
public class UserAddress extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("utf-8");
		User user = (User)req.getSession().getAttribute("loginUser");
		String flag = req.getParameter("flag");
		UserService service = new UserServiceImpl();
		System.out.println(flag);
		System.out.println(user);
		if(user!=null){
			if("default".equals(flag)){
				System.out.println(flag);
				String id = req.getParameter("id");
				System.out.println(id);
				System.out.println("userId:::"+user.getId());
				//���� �޸�Ĭ�ϵķ��� ���� addressId  �� userId
				if(service.defaultAddress(Integer.parseInt(id),user.getId())){
					flag = "show";
				}
			}
			if("update".equals(flag)){
				String id = req.getParameter("id");
				String name = req.getParameter("name");
				String phone = req.getParameter("phone");
				String detail = req.getParameter("detail");
				String level = req.getParameter("level");
				//��������
				Address addr = new Address(detail, name, phone, user.getId(), Integer.parseInt(level));
				addr.setId(Integer.parseInt(id));
				if(service.updateAddress(addr)){
					flag = "show";
				}
			}
			if("delete".equals(flag)){
				System.out.println(flag);
				String id = req.getParameter("id");
				System.out.println(id);
				if(service.deleteAddress(Integer.parseInt(id))){
					flag = "show";
				}
			}
			if("show".equals(flag)){
				System.out.println(flag);
				List<Address> list = service.getAddressList(user.getId());
				if(list!=null){
					req.getSession().setAttribute("addList", list);
				}
				resp.sendRedirect("self_info.jsp");
			}
			if("add".equals(flag)){
				String name = req.getParameter("name");
				String phone = req.getParameter("phone");
				String detail = req.getParameter("detail");
				//�������� Ĭ�ϵ�ַ�ȼ�  1���
				Address addr = new Address(detail, name, phone, user.getId(), 0);
				boolean b = service.addAddress(addr);
			
				req.getRequestDispatcher("userAddress?flag=show").forward(req, resp);
			}
			
		}else{
			resp.sendRedirect("login.jsp");
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		this.doGet(req, resp);
	}

}
