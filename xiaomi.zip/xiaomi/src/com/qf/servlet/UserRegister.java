package com.qf.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.qf.entry.User;
import com.qf.service.UserService;
import com.qf.service.impl.UserServiceImpl;
import com.qf.util.EmailUtils;
import com.qf.util.MD5Utils;
import com.qf.util.RandomUtils;
@WebServlet("/userRegister")
public class UserRegister extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("utf-8");
		String email = req.getParameter("email");
		String username = req.getParameter("username");
		String password = req.getParameter("password");
		String gender = req.getParameter("gender");
		
		UserService service = new UserServiceImpl();
		//flag ״̬��ǣ�0δ����1����2��Ч
		//role ��ɫ��0����Ա1��Ա
		//password ����ʹ�� MD5 ����  MD5Utils.md5(password)
		//code ������ ��������� ��ȡ RandomUtils.createActive()
		User user = new User(0, 1, username, MD5Utils.md5(password), email, gender, RandomUtils.createActive());
		if(service.addUser(user)){
			req.getSession().setAttribute("registerUser", user);
			//���ͼ����ʼ�
			EmailUtils.sendEmail(user);
			//����ע��ɹ�ҳ��
			resp.sendRedirect("registerSuccess.jsp");
		}else{
			req.getSession().setAttribute("registerMsg", "ע��ʧ��");
			resp.sendRedirect("register.jsp");
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		this.doGet(req, resp);
	}

}
