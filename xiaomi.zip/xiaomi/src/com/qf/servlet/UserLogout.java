package com.qf.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.qf.entry.User;
@WebServlet("/userLogout")
public class UserLogout extends HttpServlet{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("utf-8");
		User user = (User)req.getSession().getAttribute("loginUser");
		System.out.println(user);
		if(user!=null){
			req.getSession().removeAttribute("loginUser");
			req.getSession().invalidate();
		}
		Cookie[] cookies = req.getCookies();
		for(Cookie cookie:cookies){
			if("autoUser".equals(cookie.getName())){
				cookie.setMaxAge(0);
				cookie.setPath("/");
				resp.addCookie(cookie);
				System.out.println(cookie.getValue());
				break;
			}
		}
		resp.sendRedirect("login.jsp");
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		this.doGet(req, resp);
	}

}
