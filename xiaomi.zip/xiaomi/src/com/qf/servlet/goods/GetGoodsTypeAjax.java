package com.qf.servlet.goods;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.qf.service.GoodsService;
import com.qf.service.impl.GoodsServiceImpl;
import com.qf.service.impl.UserServiceImpl;
@WebServlet("/goodsTypeAjax")
public class GetGoodsTypeAjax extends HttpServlet{
//��ȡ�û��б�
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("utf-8");
		GoodsService service = new GoodsServiceImpl();
		//��ȡ �û��б� ת����json��ʽ�ַ���
		String json = new Gson().toJson(service.getGoodsTypeAjaxList());
		resp.getWriter().print(json);
		
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		this.doGet(req, resp);
	}

}
