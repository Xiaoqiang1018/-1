package com.qf.servlet.goods;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.qf.entry.Cart;
import com.qf.entry.User;
import com.qf.service.CartService;
import com.qf.service.impl.CartServiceImpl;
import com.qf.util.StrUtils;
@WebServlet("/addCart")
public class AddCart extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("utf-8");
		//�鿴�û��Ƿ��Ѿ���¼
		User user = (User)req.getSession().getAttribute("loginUser");
		if(user!=null){
			String goodsId = req.getParameter("goodsId");
			String price = req.getParameter("price");
			System.out.println(goodsId+"::"+price);
			if(StrUtils.empty(goodsId,price)){
				CartService service = new CartServiceImpl();
				Cart cart = new Cart(user.getId(),Integer.parseInt(goodsId),1,Integer.parseInt(price));
				if(service.add(cart)){
					//���ӳɹ�
					resp.sendRedirect("cartSuccess.jsp");
				}
			}else{
				resp.sendRedirect("getGoodsListByTypeId?typeId=2");
			}
		}else{
			resp.sendRedirect("login.jsp");
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		this.doGet(req, resp);
	}

}
