package com.qf.servlet.goods;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.qf.entry.Goods;
import com.qf.service.GoodsService;
import com.qf.service.impl.GoodsServiceImpl;
@WebServlet("/getGoodsById")
public class GetGoodsById extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("utf-8");
		String id = req.getParameter("id");
		GoodsService service = new GoodsServiceImpl();
		Goods goods = service.getGoodsById(Integer.parseInt(id));
		if(goods!=null){
			req.getSession().setAttribute("goods", goods);
			resp.sendRedirect("goodsDetail.jsp");
		}
		
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		this.doGet(req, resp);
	}

}
