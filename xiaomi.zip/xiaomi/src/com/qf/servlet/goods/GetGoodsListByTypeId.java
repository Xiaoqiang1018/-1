package com.qf.servlet.goods;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.qf.entry.Goods;
import com.qf.service.GoodsService;
import com.qf.service.impl.GoodsServiceImpl;
@WebServlet("/getGoodsListByTypeId")
public class GetGoodsListByTypeId extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("utf-8");
		String typeId = req.getParameter("typeId");
		GoodsService service = new GoodsServiceImpl();
		List<Goods> list = service.getGoodsListByTypeId(Integer.parseInt(typeId));
		if(list!=null){
			req.getSession().setAttribute("glist", list);
			resp.sendRedirect("goodsList.jsp");
		}else{
			System.out.println("no goods");
			resp.sendRedirect("goodsList.jsp");
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		this.doGet(req, resp);
	}

}
