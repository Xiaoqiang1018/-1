package com.qf.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.qf.entry.User;
import com.qf.service.UserService;
import com.qf.service.impl.UserServiceImpl;
@WebServlet("/checkUserName")
public class CheckUserName extends HttpServlet{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String username = req.getParameter("username");
		UserService service = new UserServiceImpl();
		System.out.println(username);
		User user = service.checkName(username);
		int msg = 0;
		if(user!=null){
			msg = 1;
		}
		resp.getWriter().print(msg);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		this.doGet(req, resp);
	}

}
