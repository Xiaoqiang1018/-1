package com.qf.servlet.admin;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.qf.service.UserService;
import com.qf.service.impl.UserServiceImpl;
//�����û�id �޸��û�״̬flag=2 �����û�Ϊ��ͣ��״̬
@WebServlet("/deleteUser")
public class DeleteUser extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("utf-8");
		String id = req.getParameter("id");
		System.out.println("user delete :"+id);
		UserService service = new UserServiceImpl();
		if(service.deleteUser(Integer.parseInt(id))){
			resp.sendRedirect("admin/userList.jsp");
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		this.doGet(req, resp);
	}

}
