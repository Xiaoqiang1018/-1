package com.qf.servlet.order;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.qf.entry.BuyGoods;
import com.qf.entry.Order;
import com.qf.entry.User;
import com.qf.service.OrderService;
import com.qf.service.impl.CartServiceImpl;
import com.qf.service.impl.OrderServiceImpl;
import com.qf.util.RandomUtils;
import com.qf.util.StrUtils;
//���ɶ���		
@WebServlet("/addOrder")
public class AddOrder extends HttpServlet{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		User user = (User)req.getSession().getAttribute("loginUser");
		if(user!=null){
			//��ȡ ǰ�˴�������aid
			String aid = req.getParameter("a");
			if(StrUtils.empty(aid)){
				//���ɶ���
				//��ȡָ���û��Ĺ��ﳵ��Ϣ
				List<BuyGoods> cartList = new CartServiceImpl().getAll(user.getId());
				//�ܽ��
				int money = 0;
				for(BuyGoods bg : cartList){
					money += bg.getMoney();
				}
				//��������
				//status 1.δ֧�� 2.��֧�� ������ 3.�ѷ��� ���ջ� 4 �������
				Order order = new Order(RandomUtils.createOrderId(), user.getId(), money, "1", null,Integer.parseInt(aid));
				OrderService service = new OrderServiceImpl();
				service.addOrder(order, cartList);
				
				resp.sendRedirect("getOrderList");
			}
		}else{
			resp.sendRedirect("login.jsp");
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		this.doGet(req, resp);
	}

}
