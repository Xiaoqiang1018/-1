package com.qf.servlet.order;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.qf.entry.Address;
import com.qf.entry.BuyGoods;
import com.qf.entry.User;
import com.qf.service.impl.CartServiceImpl;
import com.qf.service.impl.UserServiceImpl;
@WebServlet("/getOrderView")
public class GetOrderView extends HttpServlet{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		User user = (User)req.getSession().getAttribute("loginUser");
		if(user!=null){
			//����user id ��ȡ��ַ��Ϣ
			List<Address> addressList = new UserServiceImpl().getAddressList(user.getId());
			//��ȡָ���û��Ĺ��ﳵ
			List<BuyGoods> cartList = new CartServiceImpl().getAll(user.getId());
			req.setAttribute("addList", addressList);
			req.setAttribute("cartList", cartList);
			req.getRequestDispatcher("order.jsp").forward(req, resp);
		}else{
			resp.sendRedirect("login.jsp");
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		this.doGet(req, resp);
	}

}
