package com.medicin.xiaoqiang.dao;

import com.alibaba.druid.pool.DruidDataSource;

public class DruidDAO {
	private static final String url = "jdbc:mysql://localhost/medicin_xiaoqiang?characterEncoding=utf-8";
	private static final String username = "root";
	private static final String password = "root";
	public static final DruidDataSource dataSource = new DruidDataSource();
	static {
		dataSource.setDriverClassName("com.mysql.jdbc.Driver");
		dataSource.setUrl(url);
		dataSource.setUsername(username);
		dataSource.setPassword(password);
	}

}
