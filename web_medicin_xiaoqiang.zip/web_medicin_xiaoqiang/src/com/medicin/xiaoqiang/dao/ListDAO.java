/**
 * 
 */
package com.medicin.xiaoqiang.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import com.medicin.xiaoqiang.dao.DruidDAO;
import com.medicin.xiaoqiang.pojo.ChuFang;
import com.medicin.xiaoqiang.pojo.GroupList;
import com.medicin.xiaoqiang.pojo.Medicin;

/**
 * @projectname web_medicin_xiaoqiang
 * @author lenovo
 * @date 2019年1月5日
 * 
 */
public class ListDAO {

	public List<Medicin> selList(String name, Integer groupId, Integer chuFangId, int pageNum, int pageSize) {
		String sql = "SELECT a.`id`,a.`name`,`group_id` groupId,b.name groupName,`chufang_id` chuFangId,c.name chuFangName,`address`,`price`,`date` "
				+ "FROM  medicin a INNER JOIN grouplist b ON  a.group_id=b.id INNER JOIN chufang c ON a.chufang_id=c.id WHERE 1=1";
		QueryRunner queryRunner = new QueryRunner(DruidDAO.dataSource);
		List<Object> param = new ArrayList<Object>();
		if (name != null && name.trim().length() > 0) {
			sql += " and a.name like ?";
			param.add("%" + name + "%");
		}
		if (groupId != null) {
			sql += " and b.id=?";
			param.add(groupId);
		}
		if (chuFangId != null) {
			sql += " and c.id=?";
			param.add(chuFangId);
		}
		sql += " limit ?,?";
		param.add((pageNum - 1) * pageSize);
		param.add(pageSize);
		try {
			return queryRunner.query(sql, new BeanListHandler<Medicin>(Medicin.class), param.toArray());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	public long getTotalPage(String name, Integer groupId, Integer chuFangId) {
		String sql = "select count(*) from medicin where 1=1 ";
		List<Object> param = new ArrayList<Object>();
		if (name != null) {
			sql += " and name like ?";
			param.add("%" + name + "%");
		}
		if (groupId != null) {
			sql += " and group_Id=?";
			param.add(groupId);
		}
		if (chuFangId != null) {
			sql += " and chuFang_Id=?";
			param.add(chuFangId);
		}
		QueryRunner queryRunner = new QueryRunner(DruidDAO.dataSource);
		try {
			return (long) queryRunner.query(sql, new ScalarHandler<>(), param.toArray());
		} catch (SQLException e) {

			e.printStackTrace();

		}
		return 0;

	}

	public List<ChuFang> selChuFang() {
		String sql = "select id,name from chufang";
		QueryRunner queryRunner = new QueryRunner(DruidDAO.dataSource);
		try {
			return queryRunner.query(sql, new BeanListHandler<ChuFang>(ChuFang.class));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	public List<GroupList> selGroupList() {
		String sql = "select id,name from grouplist";
		QueryRunner queryRunner = new QueryRunner(DruidDAO.dataSource);
		try {
			return queryRunner.query(sql, new BeanListHandler<GroupList>(GroupList.class));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	public int insertMe(String name, int groupId, Date date, String address, int price, int chuFangId) {
		String sql = "insert into medicin(name,group_id,date,address,price,chufang_id) values(?,?,?,?,?,?)";
		QueryRunner queryRunner = new QueryRunner(DruidDAO.dataSource);
		List<Object> param = new ArrayList<Object>();
		param.add(name);
		param.add(groupId);
		param.add(date);
		param.add(address);
		param.add(price);
		param.add(chuFangId);
		try {
			return queryRunner.update(sql, param.toArray());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
	}

	public int deleteMe(int id) {
		String sql = "delete from medicin where id=?";
		QueryRunner queryRunner = new QueryRunner(DruidDAO.dataSource);
		try {
			return queryRunner.update(sql, id);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
	}

	public Medicin selList(int id) {
		String sql = "SELECT a.`id`,a.`name`,`group_id` groupId,b.name groupName,`chufang_id` chuFangId,c.name chuFangName,`address`,`price`,`date` "
				+ "FROM  medicin a INNER JOIN grouplist b ON  a.group_id=b.id INNER JOIN chufang c ON a.chufang_id=c.id WHERE a.id=?";
		QueryRunner queryRunner = new QueryRunner(DruidDAO.dataSource);

		try {
			return queryRunner.query(sql, new BeanHandler<Medicin>(Medicin.class), id);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

}
