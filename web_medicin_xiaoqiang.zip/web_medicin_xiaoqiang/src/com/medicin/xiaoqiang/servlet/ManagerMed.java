package com.medicin.xiaoqiang.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.medicin.xiaoqiang.pojo.ChuFang;
import com.medicin.xiaoqiang.pojo.GroupList;
import com.medicin.xiaoqiang.pojo.Medicin;
import com.medicin.xiaoqiang.pojo.User;
import com.medicin.xiaoqiang.service.ListService;
import com.medicin.xiaoqiang.utils.RequestUtil;

/**
 * Servlet implementation class ManagerMed
 */
@WebServlet("/manager.html")
public class ManagerMed extends HttpServlet {
	private static final long serialVersionUID = 1L;

	ListService listService = new ListService();

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		List<ChuFang> selChuFang = listService.selChuFang();
		List<GroupList> selGroupList = listService.selGroupList();
		request.setAttribute("selChuFang", selChuFang);
		request.setAttribute("selGroupList", selGroupList);
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("user");
		request.setAttribute("user", user);
		String name = request.getParameter("ym"); // 获取药品名

		Integer groupId = RequestUtil.getInt(request, "groupClass");
		Integer chuFangId = RequestUtil.getInt(request, "chuFang");
		Integer pageNum = RequestUtil.getInt(request, "pn");
		System.out.println("pn " + pageNum);
		if (pageNum == null || pageNum < 1) {
			pageNum = 1;
		}
		int pageSize = 2;

		long totalPage = listService.getTotalPage(name, groupId, chuFangId); // 获取总页数

		long lastPage = (totalPage % pageSize == 0 ? totalPage / pageSize : totalPage / pageSize + 1);

		request.setAttribute("lastPage", lastPage);
		if (totalPage > 0) {

			if (pageNum > lastPage) {
				pageNum = (int) lastPage;
			}
			request.setAttribute("pageNum", pageNum);
			System.out.println("groupId " + groupId);
			System.out.println("chuFangId " + chuFangId);
			List<Medicin> selList = listService.selList(name, groupId, chuFangId, pageNum, pageSize);

			request.setAttribute("selList", selList);

		}
		request.getRequestDispatcher("list.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request, response);
	}

}
