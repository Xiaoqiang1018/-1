package com.medicin.xiaoqiang.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.medicin.xiaoqiang.utils.RequestUtil;
import com.medicin.xiaoqiang.pojo.User;
import com.medicin.xiaoqiang.service.UserService;

@WebServlet("/user.html")
public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private UserService us = new UserService();

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String act = request.getParameter("act");

		if ("login".equals(act)) {

			login(request, response);
		} else if ("outLogin".equals(act)) {
			outLogin(request, response);
		} else if ("modifyPwd".equals(act)) {
			HttpSession session = request.getSession();
			User user = (User) session.getAttribute("user");
			request.setAttribute("user",user);
			int id = user.getId();
			request.setAttribute("id", id);
			request.getRequestDispatcher("password.jsp").forward(request, response);
		} else if ("updatePwd".equals(act)) {
			updatePwd(request, response);
		} else {
			request.getRequestDispatcher("login.jsp").forward(request, response);
		}

	}

	public void login(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String name = request.getParameter("user");
		String pwd = request.getParameter("pwd");
		com.medicin.xiaoqiang.pojo.User user = us.doLogin(name);
		
		if (user == null || !user.getPassword().equals(pwd)) {
			request.setAttribute("message", "用户或密码不正确！");
			request.getRequestDispatcher("login.jsp").forward(request, response);
		} else {
			System.out.println("ListServlet.html");
			request.getSession().setAttribute("user", user);

			response.sendRedirect("index.jsp");

		}

	}

	public void outLogin(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.getSession().invalidate(); // 让session失效
		response.sendRedirect("user.html"); // 重定向到自己

	}

	public void updatePwd(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Integer id = RequestUtil.getInt(request, "id");
		String pwd = request.getParameter("pwd");
		String repwd = request.getParameter("repwd");
		String oldPwd = request.getParameter("oldPwd");
		System.out.println("id "+id);
		int updatePasswordById = 0;
		User user = us.selUserById(id);

		if (user != null) {
			String password = user.getPassword(); // 得到用户原来的密码

			if (password != null && password.equals(oldPwd)) {

				if (pwd != null) {
					if (pwd.equals(repwd)) {
						updatePasswordById = us.updatePasswordById(id, pwd);
						if (updatePasswordById > 0) {
							request.setAttribute("message", "密码修改成功，请重新登录");
							request.getRequestDispatcher("login.jsp").forward(request, response);
						} else {
							request.setAttribute("message", "更改密码失败");
							request.getRequestDispatcher("password.jsp").forward(request, response);
						}
					}
				}
			} else {
				request.setAttribute("message", "原始密码输入不正确，无法重置密码！");
				request.getRequestDispatcher("password.jsp").forward(request, response);
			}
		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
