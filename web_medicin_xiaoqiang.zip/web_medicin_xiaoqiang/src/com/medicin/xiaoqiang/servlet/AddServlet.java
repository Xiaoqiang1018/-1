package com.medicin.xiaoqiang.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.medicin.xiaoqiang.utils.JsonUtil;
import com.medicin.xiaoqiang.pojo.User;

import com.medicin.xiaoqiang.pojo.ChuFang;
import com.medicin.xiaoqiang.pojo.GroupList;
import com.medicin.xiaoqiang.pojo.Medicin;
import com.medicin.xiaoqiang.service.ListService;
import com.medicin.xiaoqiang.utils.RequestUtil;

/**
 * Servlet implementation class AddServlet
 */
@WebServlet("/AddServlet.html")
public class AddServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	ListService listService = new ListService();

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AddServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String act = request.getParameter("act");
		if ("add".equals(act)) {
			edit(request, response);
		} else if ("insert".equals(act)) {
			insertMe(request, response);
		} else if ("del".equals(act)) {
			deleteMe(request, response);
		} else if ("go_modify".equals(act)) {
			Integer id = RequestUtil.getInt(request, "id");
			if (id != null) {
				List<GroupList> selGroupList = listService.selGroupList();
				request.setAttribute("selGroupList", selGroupList);
				List<ChuFang> selChuFang = listService.selChuFang();
				request.setAttribute("selChuFang", selChuFang);
				Medicin selList = listService.selList(id);
				System.out.println("selList:" + selList);
				request.setAttribute("selList", selList);
				request.getRequestDispatcher("edit.jsp").forward(request, response);
			} else {
				insertMe(request, response);
			}
			// request.getRequestDispatcher("edit.jsp").forward(request,
			// response);

		}

	}

	protected void edit(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		List<GroupList> selGroupList = listService.selGroupList();
		request.setAttribute("selGroupList", selGroupList);
		List<ChuFang> selChuFang = listService.selChuFang();
		request.setAttribute("selChuFang", selChuFang);
		request.getRequestDispatcher("edit.jsp").forward(request, response);
	}

	protected void deleteMe(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Integer id = RequestUtil.getInt(request, "id");
		System.out.println("id:" + id);
		int deleteMe = listService.deleteMe(id);

		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("deleteMe", deleteMe);
		map.put("message", deleteMe > 0 ? "删除成功" : "删除失败");
		response.setCharacterEncoding("utf-8");
		response.setContentType("application/json;charset=UTF-8");
		String json = JsonUtil.getJSON(map);
		PrintWriter out = response.getWriter();
		out.write(json);
		out.flush();
		out.close();
	}

	protected void insertMe(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Integer id = RequestUtil.getInt(request, "id");

		String name = request.getParameter("name");
		Integer groupId = RequestUtil.getInt(request, "group");
		Date date = RequestUtil.getDate(request, "date", "yyyy-MM-dd");

		String address = request.getParameter("address");
		Integer price = RequestUtil.getInt(request, "price");

		// HttpSession session = request.getSession();
		Integer chuFangId = RequestUtil.getInt(request, "a");
		int addLinkman = listService.insertMe(name, groupId, date, address, price, chuFangId);
		System.out.println("addLinkman:" + addLinkman);
		if (addLinkman > 0) {
			response.sendRedirect("manager.html");
		} else {
			request.setAttribute("message", "添加失败");
			request.getRequestDispatcher("edit.jsp").forward(request, response);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
