package com.medicin.xiaoqiang.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.medicin.xiaoqiang.pojo.ChuFang;
import com.medicin.xiaoqiang.pojo.Medicin;
import com.medicin.xiaoqiang.pojo.User;
import com.medicin.xiaoqiang.service.ListService;
import com.medicin.xiaoqiang.utils.RequestUtil;

/**
 * Servlet implementation class ListServlet
 */
@WebServlet("/ListServlet.html")
public class ListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	ListService listService = new ListService();

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("user");
		int id = user.getId();
		

		request.getRequestDispatcher("index.jsp").forward(request, response);

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request, response);
	}

}
