/**
 * 
 */
package com.medicin.xiaoqiang.service;

import java.util.Date;
import java.util.List;

import com.medicin.xiaoqiang.dao.ListDAO;
import com.medicin.xiaoqiang.pojo.ChuFang;
import com.medicin.xiaoqiang.pojo.GroupList;
import com.medicin.xiaoqiang.pojo.Medicin;

/**
 * @projectname web_medicin_xiaoqiang
 * @author lenovo
 * @date 2019年1月5日
 * 
 */
public class ListService {
	ListDAO listDao = new ListDAO();

	public List<Medicin> selList(String name, Integer groupId, Integer chuFangId, int pageNum, int pageSize) {
		return listDao.selList(name, groupId, chuFangId, pageNum, pageSize);

	}

	public long getTotalPage(String name, Integer groupId, Integer chuFangId) {
		return listDao.getTotalPage(name, groupId, chuFangId);
	}

	public List<ChuFang> selChuFang() {
		return listDao.selChuFang();
	}

	public List<GroupList> selGroupList() {
		return listDao.selGroupList();
	}

	public int insertMe(String name, int groupId, Date date, String address, int price, int chuFangId) {
		return listDao.insertMe(name, groupId, date, address, price, chuFangId);
	}

	public int deleteMe(int id) {
		return listDao.deleteMe(id);
	}

	public Medicin selList(int id) {
		return listDao.selList(id);
	}
}
