/**
 * 
 */
package com.medicin.xiaoqiang.pojo;

/**
 * @projectname web_medicin_xiaoqiang
 * @author lenovo
 * @date 2019年1月5日
 * 
 */
public class ChuFang {

	@Override
	public String toString() {
		return "ChuFang [id=" + id + ", name=" + name + "]";
	}
	private int id;
	private String name;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}
