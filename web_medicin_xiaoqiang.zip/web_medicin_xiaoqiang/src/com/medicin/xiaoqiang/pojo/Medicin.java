/**
 * 
 */
package com.medicin.xiaoqiang.pojo;

import java.util.Date;

/**
 * @projectname web_medicin_xiaoqiang
 * @author lenovo
 * @date 2019年1月5日
 * 
 */
public class Medicin {
	private int id;
	private String name;
	private Integer groupId;
	private String groupName;
	private Integer chuFangId;
	private String chuFangName;
	private String address;
	private int price;
	private Date date;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getGroupId() {
		return groupId;
	}
	public void setGroupId(Integer groupId) {
		this.groupId = groupId;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public Integer getChuFangId() {
		return chuFangId;
	}
	public void setChuFangId(Integer chuFangId) {
		this.chuFangId = chuFangId;
	}
	public String getChuFangName() {
		return chuFangName;
	}
	public void setChuFangName(String chuFangName) {
		this.chuFangName = chuFangName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	@Override
	public String toString() {
		return "Medicin [id=" + id + ", name=" + name + ", groupId=" + groupId + ", groupName=" + groupName
				+ ", chuFangId=" + chuFangId + ", chuFangName=" + chuFangName + ", address=" + address + ", price="
				+ price + ", date=" + date + "]";
	}

	
	
}
