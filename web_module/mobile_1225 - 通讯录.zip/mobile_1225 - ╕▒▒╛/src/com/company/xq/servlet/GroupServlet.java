/**
 * 
 */
package com.company.xq.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.company.xq.pojo.Group;
import com.company.xq.service.GroupService;
import com.company.xq.service.LinkmanService;

/**
 * @projectname mobile_1225
 * @author lenovo
 * @date 2018年12月29日
 * 
 */
@WebServlet("/GroupServlet.html")
public class GroupServlet extends HttpServlet {
	GroupService gs = new GroupService();
	LinkmanService ls = new LinkmanService();

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		List<Group> selGroupName = gs.selGroupName();
		if (selGroupName != null) {
			request.setAttribute("selGroupName", selGroupName);
		}
		
		request.getRequestDispatcher("index.jsp").forward(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		doGet(request, response);

	}

}
