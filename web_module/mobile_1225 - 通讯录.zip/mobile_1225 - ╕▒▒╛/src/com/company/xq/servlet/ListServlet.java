/**
 * 
 */
package com.company.xq.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.company.xq.pojo.Group;
import com.company.xq.pojo.Linkman;
import com.company.xq.pojo.User;
import com.company.xq.service.GroupService;
import com.company.xq.service.LinkmanService;
import com.company.xq.utils.RequestUtil;

/**
 * @projectname mobile_1225
 * @author lenovo
 * @date 2018年12月28日
 * 
 */
@WebServlet("/ListServlet.html")
public class ListServlet extends HttpServlet {
	LinkmanService linkmanService = new LinkmanService();
	GroupService groupService = new GroupService();

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("user");
		int id = user.getId();

		List<Group> selGroupName = groupService.selGroupName();
		request.setAttribute("selGroupName", selGroupName); // 下拉框信息

		String name = request.getParameter("user");

		Integer groupId = RequestUtil.getInt(request, "sel"); // id可能为空所以用自定义的RequestUtil

		Integer pageNum = RequestUtil.getInt(request, "pn");

		if (pageNum == null || pageNum < 1) {
			pageNum = 1;
		}
		Integer pageSize = 2; // 每页两行数据
		long totalPage = linkmanService.totalPage(id, name, groupId);// 得到一共有多少条数据

		if (totalPage > 0) { // z这么写的好处是，如果totalPage=0,那么就没有必要再去查询数据库了，节省开销

			// 计算尾页
			long lastPage = (totalPage % pageSize == 0 ? totalPage / pageSize : totalPage / pageSize + 1);
			request.setAttribute("lastPage", lastPage);
			if (pageNum > lastPage) {
				pageNum = (int) lastPage;
			}

			request.setAttribute("pageNum", pageNum);
			List<Linkman> linkmanList = linkmanService.showLinkmanList(id, name, groupId, pageNum, pageSize);

			request.setAttribute("linkmanList", linkmanList); // 联系人信息

		}

		request.getRequestDispatcher("index.jsp").forward(request, response);

	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		doGet(request, response);

	}

}
