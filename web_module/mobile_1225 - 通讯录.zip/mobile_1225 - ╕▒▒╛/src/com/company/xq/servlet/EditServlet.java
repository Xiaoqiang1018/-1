/**
 * 
 */
package com.company.xq.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.company.xq.pojo.Group;
import com.company.xq.pojo.Linkman;
import com.company.xq.pojo.User;
import com.company.xq.service.GroupService;
import com.company.xq.service.LinkmanService;
import com.company.xq.utils.JsonUtil;
import com.company.xq.utils.RequestUtil;

/**
 * @projectname mobile_1225
 * @author lenovo
 * @date 2018年12月30日
 * 
 */
@WebServlet("/EditServlet.html")
public class EditServlet extends HttpServlet {
	GroupService groupService = new GroupService();
	LinkmanService linkmanService = new LinkmanService();

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String act = request.getParameter("act");
		if ("add-linkman".equals(act)) { // 增加用户操作
			List<Group> selGroupName = groupService.selGroupName();
			request.setAttribute("selGroupName", selGroupName); // 下拉框信息
			request.getRequestDispatcher("add.jsp").forward(request, response); // 将下拉框信息留给add.jsp

		} else if ("go_add".equals(act)) {
			addLinkman(request, response);
			System.out.println("addLinkman");
		} else if ("del".equals(act)) {
			delLinkman(request, response);
		} else if ("go_modify".equals(act)) {
			Integer id = RequestUtil.getInt(request, "id");
			Linkman linkmanById = linkmanService.getLinkmanById(id); // 通过id查询信息放域中
			request.setAttribute("linkmanById", linkmanById);
			List<Group> selGroupName = groupService.selGroupName();
			request.setAttribute("selGroupName", selGroupName); // 分组查询信息放域中，完成了展示原来用户信息
			request.getRequestDispatcher("update.jsp").forward(request, response);

		} else if ("update2db".equals(act)) { // 更新页面再次请求时，就更新数据库了
			modifyLinkman(request, response);
		}
	}

	public void addLinkman(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String name = request.getParameter("user");
		String phone = request.getParameter("phone");
		String email = request.getParameter("email");

		Date birthday = RequestUtil.getDate(request, "birthday", "yyyy-MM-dd");
		String address = request.getParameter("address");

		Integer groupId = RequestUtil.getInt(request, "sel");
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("user");
		Integer id = user.getId();

		int addLinkman = linkmanService.addLinkman(name, phone, email, groupId, birthday, address, id);

		if (addLinkman > 0) {
			response.sendRedirect("ListServlet.html");
		} else {
			request.setAttribute("message", "添加失败");
			request.getRequestDispatcher("add.jsp").forward(request, response);
		}

	}

	public void delLinkman(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		Integer id = RequestUtil.getInt(request, "id");

		int delLinkman = linkmanService.delLinkman(id);
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("delLinkman", delLinkman);
		map.put("message", delLinkman > 0 ? "删除成功" : "删除失败");
		response.setCharacterEncoding("utf-8");
		response.setContentType("application/json;charset=UTF-8");
		String json = JsonUtil.getJSON(map);
		PrintWriter out = response.getWriter();
		out.write(json);
		out.flush();
		out.close();

	}

	public void modifyLinkman(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String name = request.getParameter("user");
		String phone = request.getParameter("phone");
		String email = request.getParameter("email");

		Date birthday = RequestUtil.getDate(request, "birthday", "yyyy-MM-dd");
		String address = request.getParameter("address");

		Integer groupId = RequestUtil.getInt(request, "sel");

		Integer id = RequestUtil.getInt(request, "id");
		int addLinkman = linkmanService.updateLinkman(id, name, phone, email, groupId, birthday, address);

		if (addLinkman > 0) {
			response.sendRedirect("ListServlet.html");
		} else {
			request.setAttribute("message", "添加失败");
			request.getRequestDispatcher("add.jsp").forward(request, response);
		}

	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		doGet(request, response);

	}

}
