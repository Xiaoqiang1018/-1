/**
 * 
 */
package com.company.xq.dao;

import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import com.company.xq.pojo.Group;

/**
 * @projectname mobile_1225
 * @author lenovo
 * @date 2018年12月29日
 * 
 */
public class GroupDAO {
	public List<Group> selGroupName() {
		String sql = "select id,name from link_group";
		QueryRunner queryRunner = new QueryRunner(DruidDAO.dataSource);
		try {
			return queryRunner.query(sql, new BeanListHandler<>(Group.class));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

}
