/**
 * 
 */
package com.company.xq.dao;

import java.sql.SQLException;
import java.util.Date;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;

import com.company.xq.pojo.User;

/**
 * @projectname mobile_1225
 * @author lenovo
 * @date 2018年12月28日
 * 
 */
public class UserDAO {

	public User selUserByName(String name) {
		String sql = "select id,username,password from user where username=?";
		QueryRunner qr = new QueryRunner(DruidDAO.dataSource);

		try {
			// new BeanHandler<>(User.class):表示封装进User的实体类；name为传入的参数
			return qr.query(sql, new BeanHandler<>(User.class), name);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null; // 有异常则返回null
		}

	}
	
	public User selUserById(Integer id) {
		String sql = "select id,username,password from user where id=?";
		QueryRunner qr = new QueryRunner(DruidDAO.dataSource);

		try {
			// new BeanHandler<>(User.class):表示封装进User的实体类；name为传入的参数
			return qr.query(sql, new BeanHandler<>(User.class), id);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null; // 有异常则返回null
		}

	}

	public int updatePasswordById(Integer id,String password) {

		String sql = "update user set password=? where id=?";
		QueryRunner queryRunner = new QueryRunner(DruidDAO.dataSource);
		try {
			return queryRunner.update(sql, password,id);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
	}

}
