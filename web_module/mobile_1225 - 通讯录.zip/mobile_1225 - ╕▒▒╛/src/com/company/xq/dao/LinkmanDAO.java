/**
 * 
 */
package com.company.xq.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import com.company.xq.pojo.Linkman;

/**
 * @projectname mobile_1225
 * @author lenovo
 * @date 2018年12月28日
 * 
 */
public class LinkmanDAO {

	public List<Linkman> selLinkmanList(Integer id, String name, Integer groupId, int pageNum, int pageSize) {
		String sql = "SELECT a.id,a.name linkman,phone,email,group_Id groupId,b.name groupName,birthday,address "
				+ "FROM linkman a LEFT JOIN link_group b ON a.group_id=b.id" + " where user_id=?";
		List<Object> param = new ArrayList<Object>();
		if (id != null) {
			param.add(id);
		}
		if (name != null && name.trim().length() > 0) { // String类型的参数要判断其是否为空格
			sql += " and a.name like ?";
			param.add("%" + name + "%"); // 模糊查询
		}
		if (groupId != null) {
			sql += " and b.id=? ";
			param.add(groupId);

		}
		sql += " limit ?,?";
		param.add((pageNum - 1) * pageSize);
		param.add(pageSize);

		QueryRunner queryRunner = new QueryRunner(DruidDAO.dataSource);
		try {
			return queryRunner.query(sql, new BeanListHandler<Linkman>(Linkman.class), param.toArray());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

		}
		return null;

	}

	public long getTotalPage(Integer id, String name, Integer groupId) {
		String sql = "SELECT count(a.id) " + "FROM linkman a LEFT JOIN link_group b ON a.group_id=b.id"
				+ " where user_id=?";
		List<Object> param = new ArrayList<Object>();
		if (id != null) {
			param.add(id);
		}
		if (name != null && name.trim().length() > 0) { // String类型的参数要判断其是否为空格
			sql += " and a.name like ?";
			param.add("%" + name + "%"); // 模糊查询
		}
		if (groupId != null) {
			sql += " and b.id=? ";
			param.add(groupId);

		}
		QueryRunner queryRunner = new QueryRunner(DruidDAO.dataSource);
		try {
			return (long) queryRunner.query(sql, new ScalarHandler<>(), param.toArray());
		} catch (SQLException e) {

			e.printStackTrace();

		}
		return 0;

	}

	// 添加用户
	public int insertLinkman(String name, String phone, String email, Integer groupId, Date birthday, String address,
			Integer id) {
		String sql = "insert into linkman(name,phone, `EMAIL`,`GROUP_ID`, `BIRTHDAY`,`ADDRESS`,`USER_ID`) "
				+ " values(?,?,?,?,?,?,?)";
		List<Object> param = new ArrayList<Object>();
		param.add(name);
		param.add(phone);
		param.add(email);
		param.add(groupId);
		param.add(birthday);
		param.add(address);
		param.add(id);

		QueryRunner queryRunner = new QueryRunner(DruidDAO.dataSource);
		try {
			return queryRunner.update(sql, param.toArray());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
	}

	// 删除联系人
	public int delLinkman(Integer id) {
		String sql = "delete from linkman where id=?";
		QueryRunner queryRunner = new QueryRunner(DruidDAO.dataSource);
		try {
			return queryRunner.update(sql, id);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
	}

	// 修改联系人
	public int updateLinkman(int id, String name, String phone, String email, Integer groupId, Date birthday,
			String address) {
		String sql = "update  linkman set name=?,phone=?,email=?,group_Id=?,birthday=?,address=? where id=?";
		QueryRunner queryRunner = new QueryRunner(DruidDAO.dataSource);
		List<Object> param = new ArrayList<Object>();
		
		param.add(name);
		param.add(phone);
		param.add(email);
		param.add(groupId);
		param.add(birthday);
		param.add(address);
		param.add(id);

		try {
			return queryRunner.update(sql, param.toArray());
		} catch (SQLException e) {

			e.printStackTrace();
		}
		return 0;
	}

	// 修改联系人 根据联系人id获取联系人
	public Linkman getLinkmanById(Integer id) {
		String sql = "select id,name linkman,group_id groupId,phone,email,birthday,address from linkman where id=?";
		QueryRunner queryRunner = new QueryRunner(DruidDAO.dataSource);

		try {
			return queryRunner.query(sql, new BeanHandler<Linkman>(Linkman.class), id);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

}
