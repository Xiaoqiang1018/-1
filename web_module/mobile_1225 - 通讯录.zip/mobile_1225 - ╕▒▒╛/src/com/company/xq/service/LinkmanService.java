/**
 * 
 */
package com.company.xq.service;

import java.util.Date;
import java.util.List;

import com.company.xq.dao.LinkmanDAO;
import com.company.xq.pojo.Linkman;

/**
 * @projectname mobile_1225
 * @author lenovo
 * @date 2018年12月29日
 * 
 */
public class LinkmanService {
	LinkmanDAO linkmanDAO = new LinkmanDAO();

	public List<Linkman> showLinkmanList(Integer id, String name, Integer groupId, int pageNum, int pageSize) {

		return linkmanDAO.selLinkmanList(id, name, groupId, pageNum, pageSize);
	}

	// 获取总页数
	public long totalPage(Integer id, String name, Integer groupId) {
		return linkmanDAO.getTotalPage(id, name, groupId);
	}

	// 添加联系人
	public int addLinkman(String name, String phone, String email, Integer groupId, Date birthday, String address,
			Integer id) {
		return linkmanDAO.insertLinkman(name, phone, email, groupId, birthday, address, id);
	}

	// 删除联系人
	public int delLinkman(Integer id) {
		return linkmanDAO.delLinkman(id);
	}

	public int updateLinkman(int userId, String name, String phone, String email, Integer groupId, Date birthday,
			String address) {
		return linkmanDAO.updateLinkman(userId, name, phone, email, groupId, birthday, address);
	}

	public Linkman getLinkmanById(Integer id) {
		return linkmanDAO.getLinkmanById(id);

	}
}
