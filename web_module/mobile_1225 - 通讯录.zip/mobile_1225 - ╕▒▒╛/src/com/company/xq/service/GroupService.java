/**
 * 
 */
package com.company.xq.service;

import java.util.List;

import com.company.xq.dao.GroupDAO;
import com.company.xq.pojo.Group;

/**
 * @projectname mobile_1225
 * @author lenovo
 * @date 2018年12月29日
 * 
 */
public class GroupService {

	public List<Group> selGroupName() {
		GroupDAO group = new GroupDAO();
		return group.selGroupName();
	}
}
