/**
 * 
 */
package com.company.xq.service;

import com.company.xq.dao.UserDAO;
import com.company.xq.pojo.User;

/**
 * @projectname mobile_1225
 * @author lenovo
 * @date 2018年12月28日
 * 
 */
public class UserService {
	UserDAO userDAO = new UserDAO();

	public User doLogin(String name) {

		return userDAO.selUserByName(name);
	}

	public int updatePasswordById(Integer id, String password) {
		return userDAO.updatePasswordById(id, password);
	}

	public User selUserById(Integer id) {
		return userDAO.selUserById(id);
	}
}
