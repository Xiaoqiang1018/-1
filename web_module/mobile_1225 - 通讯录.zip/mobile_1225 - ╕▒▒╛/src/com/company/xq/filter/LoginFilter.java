/**
 * 
 */
package com.company.xq.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @projectname mobile_1225
 * @author lenovo
 * @date 2018年12月25日
 * 
 */
@WebFilter("*.html")
public class LoginFilter implements Filter {


	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		// TODO Auto-generated method stub

	}

	
	@Override
	public void doFilter(ServletRequest request1, ServletResponse response1, FilterChain chain)
			throws IOException, ServletException {
		
		HttpServletRequest request = (HttpServletRequest) request1;
		HttpServletResponse response = (HttpServletResponse) response1;
		response.setCharacterEncoding("utf-8");
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=UTF-8");
		//System.out.println(request.getServletPath());
		if("/UserServlet.html".equals(request.getServletPath())){  //当请求的路径为登陆或退出登陆的servlet时，不拦截
			chain.doFilter(request, response);
			return;
		}
		if (request.getSession().getAttribute("user") == null) {   //session里面没信息，代表你没有登陆
			response.sendRedirect("login.jsp");
		}else {
			chain.doFilter(request, response);
		}
	}

	
	@Override
	public void destroy() {
		// TODO Auto-generated method stub

	}

}
