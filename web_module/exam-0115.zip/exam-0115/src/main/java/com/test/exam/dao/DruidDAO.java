package com.test.exam.dao;

import com.alibaba.druid.pool.DruidDataSource;

public class DruidDAO {
	private static final String url = "jdbc:mysql://10.9.63.171/1811?characterEncoding=utf-8";
	private static final String username = "root";
	private static final String password = "root";
	public static final DruidDataSource dataSource = new DruidDataSource();
	static {
		dataSource.setDriverClassName("com.mysql.jdbc.Driver");
		dataSource.setUrl(url);
		dataSource.setUsername(username);
		dataSource.setPassword(password);
	}

}
