package com.test.exam.service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.test.exam.dao.AccountDAO;
import com.test.exam.dao.AccountDAOImpl;
import com.test.exam.dao.AccountJDBCImpl;
import com.test.exam.pojo.AccountCriteria;
import com.test.exam.pojo.WechatAccount;

public class AccountService {
    private AccountDAO accountDAO = new AccountDAOImpl();
    public PageInfo<WechatAccount> getAccountList(AccountCriteria criteria, Integer pageNum, Integer pageSize) {
        PageHelper.startPage(pageNum, pageSize);
        return new PageInfo<>(accountDAO.getAccountList(criteria), 5);
    }
}
