package com.test.exam.service;

import com.test.exam.dao.AccountTypeDAO;
import com.test.exam.pojo.AccountType;

import java.util.List;

public class TypeService {
    private AccountTypeDAO typeDAO = new AccountTypeDAO();

    public List<AccountType> getAllType() {
        return typeDAO.getAllType();
    }

}
