package com.test.exam.dao;

import com.test.exam.pojo.AccountCriteria;
import com.test.exam.pojo.WechatAccount;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class AccountJDBCImpl implements AccountDAO{
    @Override
    public List<WechatAccount> getAccountList(AccountCriteria criteria) {
        String sql="select a.id,a.`NAME`,a.CREATED_DATE,a.`STATUS`,a.TYPE_ID,a.ACCOUNT,t.`NAME` TNAME\n" +
                "        from wechat_account a\n" +
                "        inner join account_type t on a.TYPE_ID=t.id where 1=1 ";
        List<Object> params=new ArrayList<>();
        if(criteria.getStart()!=null){
            sql+="  AND A.CREATED_DATE >?";
            params.add(criteria.getStart());
        }
        QueryRunner runner=new QueryRunner(DruidDAO.dataSource);
        try {
           return runner.query(sql,new BeanListHandler<>(WechatAccount.class),params.toArray());
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }


}
