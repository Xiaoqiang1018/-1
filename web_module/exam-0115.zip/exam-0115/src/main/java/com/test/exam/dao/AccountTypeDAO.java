package com.test.exam.dao;

import com.test.exam.pojo.AccountType;
import org.apache.ibatis.session.SqlSession;

import java.util.List;

public class AccountTypeDAO {

    public List<AccountType> getAllType() {
        SqlSession session = BaseDAO.getSession();
        try {
            List<AccountType> list = session.selectList("TypeMapper.getAllType");
            return list;
        } finally {
            session.close();
        }
    }
}
