package com.test.exam.dao;

import com.test.exam.pojo.AccountCriteria;
import com.test.exam.pojo.WechatAccount;

import java.util.List;

public interface AccountDAO {
    List<WechatAccount> getAccountList(AccountCriteria criteria);
}
