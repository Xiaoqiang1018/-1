package com.test.exam.dao;

import com.test.exam.pojo.AccountCriteria;
import com.test.exam.pojo.WechatAccount;
import org.apache.ibatis.session.SqlSession;

import java.util.List;

public class AccountDAOImpl implements AccountDAO {
    @Override
    public List<WechatAccount> getAccountList(AccountCriteria criteria) {
        SqlSession session = BaseDAO.getSession();
        try {
            return session.selectList("AccountMapper.getAccountList", criteria);
        } finally {
            session.close();
        }
    }
}
