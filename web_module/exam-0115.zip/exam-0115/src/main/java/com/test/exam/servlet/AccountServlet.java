package com.test.exam.servlet;

import com.github.pagehelper.PageInfo;
import com.test.exam.pojo.AccountCriteria;
import com.test.exam.pojo.AccountType;
import com.test.exam.pojo.WechatAccount;
import com.test.exam.service.AccountService;
import com.test.exam.service.TypeService;
import com.test.exam.util.RequestUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Date;
import java.util.List;

@WebServlet("/account.html")
public class AccountServlet extends HttpServlet {
    private TypeService typeService = new TypeService();
    private AccountService accountService = new AccountService();

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String act = request.getParameter("act");
        if ("list".equals(act)) {
            list(request, response);
        }
    }

    protected void list(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<AccountType> types = typeService.getAllType();
        request.setAttribute("types", types);

        Integer pn = RequestUtil.getInt(request, "pn");
        if (pn == null || pn < 1) {
            pn = 1;
        }
        Integer typeId = RequestUtil.getInt(request, "typeId");
        String keyword = request.getParameter("keyword");
        Date start = RequestUtil.getDate(request, "start", "yyyy-MM-dd");
        Date end = RequestUtil.getDate(request, "end", "yyyy-MM-dd");
        AccountCriteria criteria = new AccountCriteria();
        criteria.setEnd(end);
        criteria.setStart(start);
        criteria.setKeywords(keyword);
        criteria.setTypeId(typeId);
        PageInfo<WechatAccount> pageInfo = accountService.getAccountList(criteria, pn, 2);
        request.setAttribute("pageInfo", pageInfo);
        request.getRequestDispatcher("list.jsp").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doGet(request, response);
    }
}
