package com.hr.xiaoqiang.servlet;

import com.github.pagehelper.PageInfo;
import com.hr.xiaoqiang.pojo.Dept;
import com.hr.xiaoqiang.service.DeptService;
import com.hr.xiaoqiang.utils.RequestUtil;
import org.springframework.context.ApplicationContext;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/dept.html")
public class DeptServlet extends HttpServlet {
    private DeptService DeptServiceImpl;

    @Override
    public void init(ServletConfig config) throws ServletException {
        ApplicationContext Context = (ApplicationContext) config.getServletContext().getAttribute("APPLICATION_CONTEXT_CONSTANCES");
        DeptServiceImpl = Context.getBean(DeptService.class);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        response.setCharacterEncoding("utf-8");
        Integer pageNum = RequestUtil.getInt(request, "pn");
        if (pageNum == null) {
            pageNum = 1;
        }
        PageInfo<Dept> deptList = DeptServiceImpl.getDeptList(pageNum, 2);
        request.setAttribute("deptList", deptList);
        request.getRequestDispatcher("listDepartment.jsp").forward(request, response);
    }

}
