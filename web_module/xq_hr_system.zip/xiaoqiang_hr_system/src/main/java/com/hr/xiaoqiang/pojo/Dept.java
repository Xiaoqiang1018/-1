package com.hr.xiaoqiang.pojo;

public class Dept {
    private Integer id;
    private String deptment;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getDeptment() {
        return deptment;
    }

    public void setDeptment(String deptment) {
        this.deptment = deptment;
    }

    @Override
    public String toString() {
        return "Dept{" +
                "id=" + id +
                ", deptment='" + deptment + '\'' +
                '}';
    }
}
