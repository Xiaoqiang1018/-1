package com.hr.xiaoqiang.service;

import com.github.pagehelper.PageInfo;
import com.hr.xiaoqiang.pojo.Post;

import java.util.List;

public interface PostService {
    PageInfo<Post> getPostList(int pageNum, int pageSize);

    int addPost(Integer pid, String postName);

    List<Post> getPostListByPid(Integer pId);
}
