package com.hr.xiaoqiang.service;

import com.github.pagehelper.PageInfo;
import com.hr.xiaoqiang.pojo.Dept;

import java.util.List;

public interface DeptService {
    int addDept(String dept);

    PageInfo<Dept> getDeptList(int pageNum, int pageSize);

    List<Dept> getDeptList();
}
