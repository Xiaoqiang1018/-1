package com.hr.xiaoqiang.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.hr.xiaoqiang.dao.DeptDAO;
import com.hr.xiaoqiang.pojo.Dept;
import com.hr.xiaoqiang.service.DeptService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DeptServiceImpl implements DeptService {
    @Autowired
    private DeptDAO deptDAO;

    @Override
    public int addDept(String dept) {
        return deptDAO.addDept(dept);
    }

    @Override
    public PageInfo<Dept> getDeptList(int pageNum, int pageSize) {
        PageHelper.startPage(pageNum, pageSize);
        List<Dept> deptList = deptDAO.getDeptList();
        return new PageInfo<>(deptList);
    }

    @Override
    public List<Dept> getDeptList() {
        return deptDAO.getDeptList();
    }
}
