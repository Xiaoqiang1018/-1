package com.hr.xiaoqiang.service;

import com.github.pagehelper.PageInfo;
import com.hr.xiaoqiang.pojo.Staff;
import org.apache.ibatis.annotations.Param;

import java.util.Date;
import java.util.List;

public interface StaffService {
    PageInfo<Staff> getStaffList(Integer deptId, Integer postId, String name,int pageNum,int pageSize);

    int addStaff(@Param("name") String name, @Param("sex") Integer sex, @Param("date") Date date, @Param("deptId") Integer deptId, @Param("postId") Integer postId);
}
