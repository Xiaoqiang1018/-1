package com.hr.xiaoqiang.servlet;

import com.hr.xiaoqiang.pojo.Dept;
import com.hr.xiaoqiang.service.DeptService;
import com.hr.xiaoqiang.service.PostService;
import com.hr.xiaoqiang.utils.RequestUtil;
import org.springframework.context.ApplicationContext;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/editPost.html")
public class EditPostServlet extends HttpServlet {
    private PostService PostServiceImpl;
    private DeptService deptServiceImpl;

    @Override
    public void init(ServletConfig config) throws ServletException {
        ApplicationContext Context = (ApplicationContext) config.getServletContext().getAttribute("APPLICATION_CONTEXT_CONSTANCES");
        PostServiceImpl = Context.getBean(PostService.class);
        deptServiceImpl = Context.getBean(DeptService.class);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        response.setCharacterEncoding("utf-8");
        String act = request.getParameter("act");
        if ("addPost".equals(act)) {
            addPost(request, response);
        } else if ("addInTab".equals(act)) {
            addInTab(request, response);
        }
    }

    protected void addPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Dept> deptList = deptServiceImpl.getDeptList();
        System.out.println("deptList========" + deptList);
        if (deptList != null) {
            request.setAttribute("deptList", deptList);
        }
        request.getRequestDispatcher("addOrEditPost.jsp").forward(request, response);
    }

    protected void addInTab(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Integer deptId = RequestUtil.getInt(request, "deptId");
        String postName = request.getParameter("postName");
        int i = PostServiceImpl.addPost(deptId, postName);
        if (i > 0) {
            response.sendRedirect("post.html");
        } else {
            request.setAttribute("message", "添加失败，重新添加");
            request.getRequestDispatcher("addOrEditPost.jsp").forward(request, response);
        }
    }
}
