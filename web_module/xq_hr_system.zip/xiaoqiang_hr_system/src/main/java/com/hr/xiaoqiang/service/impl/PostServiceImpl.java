package com.hr.xiaoqiang.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.hr.xiaoqiang.dao.PostDAO;
import com.hr.xiaoqiang.pojo.Post;
import com.hr.xiaoqiang.service.PostService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PostServiceImpl implements PostService {
    @Autowired
    private PostDAO postDAO;

    @Override
    public PageInfo<Post> getPostList(int pageNum, int pageSize) {
        PageHelper.startPage(pageNum, pageSize);
        List<Post> postList = postDAO.getPostList();
        return new PageInfo<>(postList);
    }

    @Override
    public int addPost(Integer pid, String postName) {
        return postDAO.addPost(pid, postName);
    }

    @Override
    public List<Post> getPostListByPid(Integer pId) {
        return postDAO.getPostListByPid(pId);
    }
}
