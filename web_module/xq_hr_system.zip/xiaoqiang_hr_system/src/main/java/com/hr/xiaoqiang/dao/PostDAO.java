package com.hr.xiaoqiang.dao;

import com.hr.xiaoqiang.pojo.Post;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface PostDAO {
    List<Post> getPostList();

    int addPost(@Param("pid") Integer pid, @Param("postName") String postName);

    List<Post> getPostListByPid(Integer pId);

}
