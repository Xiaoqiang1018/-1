package com.hr.xiaoqiang.servlet;

import com.github.pagehelper.PageInfo;
import com.hr.xiaoqiang.pojo.Dept;
import com.hr.xiaoqiang.pojo.Staff;
import com.hr.xiaoqiang.service.DeptService;
import com.hr.xiaoqiang.service.PostService;
import com.hr.xiaoqiang.service.StaffService;
import com.hr.xiaoqiang.utils.RequestUtil;
import org.springframework.context.ApplicationContext;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Date;
import java.util.List;

@WebServlet("/addStaff.html")
public class AddStaffServlet extends HttpServlet {
    private StaffService StaffServiceImpl;
    private DeptService DeptServiceImpl;

    @Override
    public void init(ServletConfig config) throws ServletException {
        ApplicationContext Context = (ApplicationContext) config.getServletContext().getAttribute("APPLICATION_CONTEXT_CONSTANCES");
        StaffServiceImpl = Context.getBean(StaffService.class);
        DeptServiceImpl = Context.getBean(DeptService.class);

    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        response.setCharacterEncoding("utf-8");
        String act = request.getParameter("act");
        if ("addStaff".equals(act)) {
            addStaff(request, response);
        } else if ("insert".equals(act)) {
            add(request, response);
        }else if("search".equals(act)){
            search(request,response);
        }
    }

    protected void addStaff(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Dept> dept = DeptServiceImpl.getDeptList();
        request.setAttribute("dept", dept);
        request.getRequestDispatcher("addStaff.jsp").forward(request, response);
    }

    protected void add(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String staffName = request.getParameter("staffName");
        Integer sex = RequestUtil.getInt(request, "gender");
        Date date = RequestUtil.getDate(request, "onDutyDate", "yyyy-MM-dd");
        Integer deptId = RequestUtil.getInt(request, "crmPost");
        Integer postId = RequestUtil.getInt(request, "crm");

        int i = StaffServiceImpl.addStaff(staffName, sex, date, deptId, postId);
        if (i > 0) {
            response.sendRedirect("staff.html");
        } else {
            request.getRequestDispatcher("addStaff.jsp").forward(request, response);
        }
    }
    protected void search(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//        List<Dept> deptList = DeptServiceImpl.getDeptList();
//        Integer deptId = RequestUtil.getInt(request, "crmPost");
//        Integer postId = RequestUtil.getInt(request, "crm");
//        String staffName = request.getParameter("staff");
//        Integer pn = RequestUtil.getInt(request, "pn");
//        if (pn == null) {
//            pn = 1;
//        }
//        PageInfo<Staff> staffList = StaffServiceImpl.getStaffList(deptId, postId, staffName, pn, 2);
//        request.setAttribute("deptList", deptList);
//        request.setAttribute("staffList", staffList);
//        request.getRequestDispatcher("listStaff.jsp").forward(request, response);
    }
}
