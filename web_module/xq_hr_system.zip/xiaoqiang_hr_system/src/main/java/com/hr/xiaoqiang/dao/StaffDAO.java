package com.hr.xiaoqiang.dao;

import com.hr.xiaoqiang.pojo.Staff;
import org.apache.ibatis.annotations.Param;

import java.util.Date;
import java.util.List;

public interface StaffDAO {
    List<Staff> getStaffList(@Param("deptId") Integer deptId, @Param("postId") Integer postId, @Param("name") String name);

    int addStaff(@Param("name") String name, @Param("sex") Integer sex, @Param("date") Date date, @Param("deptId") Integer deptId, @Param("postId") Integer postId);
}
