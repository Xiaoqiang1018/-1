package com.hr.xiaoqiang.servlet;

import com.hr.xiaoqiang.service.DeptService;
import org.springframework.context.ApplicationContext;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/edit.html")
public class EditServlet extends HttpServlet {
    private DeptService DeptServiceImpl;

    @Override
    public void init(ServletConfig config) throws ServletException {
        ApplicationContext Context = (ApplicationContext) config.getServletContext().getAttribute("APPLICATION_CONTEXT_CONSTANCES");
        DeptServiceImpl = Context.getBean(DeptService.class);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        response.setCharacterEncoding("utf-8");
        String act = request.getParameter("act");
        if ("addDept".equals(act)) {
            addDept(request, response);
        }
    }

    protected void addDept(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String depName = request.getParameter("depName");
        int i = DeptServiceImpl.addDept(depName);
        if (i > 0) {
            response.sendRedirect("dept.html");
        } else {
            request.setAttribute("message", "添加失败，重新添加");
            request.getRequestDispatcher("addOrEditDepartment.jsp").forward(request, response);
        }
    }
}
