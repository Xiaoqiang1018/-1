package com.hr.xiaoqiang.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.hr.xiaoqiang.dao.StaffDAO;
import com.hr.xiaoqiang.pojo.Staff;
import com.hr.xiaoqiang.service.StaffService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
public class StaffServiceImpl implements StaffService {
    @Autowired
    private StaffDAO staffDAO;

    @Override
    public PageInfo<Staff> getStaffList(Integer deptId, Integer postId, String name, int pageNum, int pageSize) {
        PageHelper.startPage(pageNum, pageSize);
        List<Staff> staffList = staffDAO.getStaffList(deptId, postId, name);
        return new PageInfo<>(staffList);
    }

    @Override
    public int addStaff(String name, Integer sex, Date date, Integer deptId, Integer postId) {
        return staffDAO.addStaff(name, sex, date, deptId, postId);
    }
}
