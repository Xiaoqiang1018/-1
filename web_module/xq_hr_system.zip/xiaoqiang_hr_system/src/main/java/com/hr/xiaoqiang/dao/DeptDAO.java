package com.hr.xiaoqiang.dao;

import com.hr.xiaoqiang.pojo.Dept;

import java.util.List;

public interface DeptDAO {
    int addDept(String dept);

    List<Dept> getDeptList();
}
