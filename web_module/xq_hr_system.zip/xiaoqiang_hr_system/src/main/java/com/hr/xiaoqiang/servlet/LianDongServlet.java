package com.hr.xiaoqiang.servlet;

import com.hr.xiaoqiang.pojo.Post;
import com.hr.xiaoqiang.service.PostService;
import com.hr.xiaoqiang.utils.JsonUtil;
import com.hr.xiaoqiang.utils.RequestUtil;
import org.springframework.context.ApplicationContext;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

@WebServlet("/lian.html")
public class LianDongServlet extends HttpServlet {
    private PostService PostServiceImpl;

    @Override
    public void init(ServletConfig config) throws ServletException {
        ApplicationContext Context = (ApplicationContext) config.getServletContext().getAttribute("APPLICATION_CONTEXT_CONSTANCES");
        PostServiceImpl = Context.getBean(PostService.class);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        response.setCharacterEncoding("utf-8");
        Integer deptId = RequestUtil.getInt(request, "id"); //获取部门id
        System.out.println("获取部门id==========="+deptId);
        List<Post> postListByPid = PostServiceImpl.getPostListByPid(deptId);
        System.out.println("结果=========="+postListByPid);
        response.setCharacterEncoding("utf-8");
        response.setContentType("application/json;charset=utf-8");
        PrintWriter out = response.getWriter();
        String json = JsonUtil.getJSON(postListByPid);
        out.write(json);
        out.flush();
        out.close();
    }
}
