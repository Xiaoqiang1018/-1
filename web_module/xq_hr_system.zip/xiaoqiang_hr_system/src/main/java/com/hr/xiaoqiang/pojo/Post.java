package com.hr.xiaoqiang.pojo;

public class Post {
    private Integer id;
    private Integer pid;
    private String postName;
    private Dept dept;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getPid() {
        return pid;
    }

    public void setPid(Integer pid) {
        this.pid = pid;
    }

    public String getPostName() {
        return postName;
    }

    public void setPostName(String postName) {
        this.postName = postName;
    }

    public Dept getDept() {
        return dept;
    }

    public void setDept(Dept dept) {
        this.dept = dept;
    }

    @Override
    public String toString() {
        return "Post{" +
                "id=" + id +
                ", pid=" + pid +
                ", postName='" + postName + '\'' +
                ", dept=" + dept +
                '}';
    }
}
