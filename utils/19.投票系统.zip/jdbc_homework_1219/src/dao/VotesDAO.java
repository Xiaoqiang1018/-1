package dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import pojo.Votes;

public class VotesDAO {
	public List<Votes> getVotesBySubjectId(Integer subjectId) {
		String sql = "select id,content,vote_cnt from votes where subject_id=?";
		BaseDAO dao = new BaseDAO();
		try {
			List<Object> params = new ArrayList<>();
			params.add(subjectId);
			ResultSet result = dao.excuteQuery(sql, params);
			List<Votes> list = new ArrayList();// 有多条查询结果，封装成实体类集合
			while (result.next()) {
				Votes vote = new Votes();
				vote.setContent(result.getString("content"));
				vote.setId(result.getInt("id"));
				vote.setVoteCnt(result.getInt("vote_cnt"));
				list.add(vote);
			}
			return list;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dao.close();
		}
		return null;
	}

	public void updateVoteCount(int id) {
		String sql = "update votes set vote_cnt=vote_cnt+1 where id=?";
		BaseDAO dao = new BaseDAO();
		try {
			List<Object> params = new ArrayList<>();
			params.add(id);
			dao.excuteUpdate(sql, params);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dao.close();
		}
	}

	public void vote(int voteId, int subjectId) {

		BaseDAO dao = new BaseDAO(false);// false代表手动提交事务
		try {
			List<Object> params = new ArrayList<>();
			String sql = "update votes set vote_cnt=vote_cnt+1 where id=?";
			params.add(voteId);
			dao.excuteUpdate(sql, params);// 更新选项的投票数
			String sql2 = "update subject set vote_cnt=vote_cnt+1 where id=?";
			params.clear();
			params.add(subjectId);
			dao.excuteUpdate(sql2, params);// 更新题目的总票数
			dao.commit();// 提交事务
		} catch (Exception e) {
			try {
				dao.rollback();// 回滚
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			dao.close();
		}
	}
}
