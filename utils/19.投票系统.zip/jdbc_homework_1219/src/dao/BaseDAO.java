package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class BaseDAO {
	private static final String url = "jdbc:mysql://10.9.63.171/1811?characterEncoding=utf-8";
	private static final String username = "root";
	private static final String password = "root";
	private Connection connection = null;
	private PreparedStatement statement = null;
	private ResultSet resultSet = null;
	private boolean autoCommit = true;

	static {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	public BaseDAO() {

	}

	public BaseDAO(boolean auto) {
		this.autoCommit = auto;
	}

	private void open() {
		try {
			connection = DriverManager.getConnection(url, username, password);
			connection.setAutoCommit(autoCommit);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public ResultSet excuteQuery(String sql, List<Object> params) throws SQLException {
		if (connection == null || connection.isClosed()) {
			open();
		}
		statement = connection.prepareStatement(sql);
		if (params != null && !params.isEmpty()) {
			for (int i = 0; i < params.size(); i++) {
				statement.setObject(i + 1, params.get(i));
			}
		}
		resultSet = statement.executeQuery();
		return resultSet;
	}

	public void commit() throws SQLException {
		connection.commit();
	}

	public void rollback() throws SQLException {
		connection.rollback();
	}

	public int excuteUpdate(String sql, List<Object> params) throws SQLException {
		if (connection == null || connection.isClosed()) {
			open();
		}
		statement = connection.prepareStatement(sql);
		if (params != null && !params.isEmpty()) {
			for (int i = 0; i < params.size(); i++) {
				statement.setObject(i + 1, params.get(i));
			}
		}
		return statement.executeUpdate();
	}

	public void close() {
		try {
			if (resultSet != null && !resultSet.isClosed()) {
				resultSet.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			if (statement != null && !statement.isClosed()) {
				statement.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			if (connection != null && !connection.isClosed()) {
				connection.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
