package dao;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import pojo.Subject;

public class SubjectDAO {
	public void getAllSubject() {
		String sql = "select id,title,create_date,vote_cnt,view_cnt from subject";
		BaseDAO dao = new BaseDAO();
		try {
			ResultSet result = dao.excuteQuery(sql, null);
			System.out.println("序号 \t 主题\t\t\t 投票/查看\t 创建时间");
			while (result.next()) {
				System.out.print(result.getString("id") + "\t");
				System.out.print(result.getString("title") + "\t");
				System.out.print(result.getString("vote_cnt") + "/" + result.getString("view_cnt") + "\t");
				System.out.println(result.getString("create_date"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dao.close();
		}
	}

	public Subject getSubjectById(Integer id) {
		String sql = "select id,title,create_date,vote_cnt,view_cnt from subject where id=?";
		BaseDAO dao = new BaseDAO();
		try {
			List<Object> params = new ArrayList<>();
			params.add(id);
			Subject subject = null;//把查询结果封装成实体类，只有一条查询结果，封装成一个实体类对象
			ResultSet result = dao.excuteQuery(sql, params);
			if (result.next()) {
				subject = new Subject();
				subject.setId(result.getInt("id"));
				subject.setTitle(result.getString("title"));
				subject.setCreatedDate(result.getDate("create_date"));
				subject.setViewCnt(result.getInt("view_cnt"));
				subject.setVoteCnt(result.getInt("vote_cnt"));
				// System.out.println(result.getString("title"));
				// System.out.println(result.getString("vote_cnt") + "次投票、" +
				// result.getString("view_cnt") + "次查看");
			}
			return subject;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dao.close();
		}
		return null;
	}

	public void updateSubject(Subject subject) {
		String sql = "update subject set vote_cnt=? ,view_cnt=? where id=?";
		BaseDAO dao = new BaseDAO();
		try {
			List<Object> params = new ArrayList<>();
			params.add(subject.getVoteCnt());
			params.add(subject.getViewCnt());
			params.add(subject.getId());
			dao.excuteUpdate(sql, params);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dao.close();
		}
	}
}
