package test;

import java.util.Scanner;

import service.SubjectService;

public class HomeWork {
	public static void main(String[] args) {
		SubjectService subjectService = new SubjectService();
		subjectService.listSubject();
		System.out.println("请选择要投票的题目：");
		Scanner sc = new Scanner(System.in);
		Integer id = Integer.parseInt(sc.nextLine());
		subjectService.showDetail(id);
	}
}
