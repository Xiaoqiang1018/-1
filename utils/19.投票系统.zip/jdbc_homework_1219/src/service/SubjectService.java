package service;

import java.util.List;
import java.util.Scanner;

import dao.SubjectDAO;
import dao.VotesDAO;
import pojo.Subject;
import pojo.Votes;

public class SubjectService {
	private SubjectDAO subjectDAO = new SubjectDAO();
	private VotesDAO voteDAO = new VotesDAO();

	public void listSubject() {
		subjectDAO.getAllSubject();
	}

	public void showDetail(Integer id) {
		Subject subject = subjectDAO.getSubjectById(id);
		if (subject == null) {
			System.out.println("主题不存在");
			return;
		}
		subject.setViewCnt(subject.getViewCnt() + 1);// 在原来的次数上+1
		subjectDAO.updateSubject(subject);// 更新浏览次数
		System.out.println(subject.getTitle());
		System.out.println(subject.getVoteCnt() + "次投票、" + subject.getViewCnt() + "次查看");
		System.out.println();
		List<Votes> votes = voteDAO.getVotesBySubjectId(id);// 查询出当前这个主题下所有的选项
		for (int i = 0; i < votes.size(); i++) {
			Votes v = votes.get(i);
			float percent = subject.getVoteCnt() == 0 ? 0f : v.getVoteCnt() * 100f / subject.getVoteCnt();// 计算百分比，0不能作为除数
			// 第一列的编号，是表示第几个选项，而不是选项的id,所以是i+1
			System.out.println((i + 1) + "\t" + v.getContent() + "\t" + v.getVoteCnt() + "/" + subject.getVoteCnt()
					+ " " + String.format("%.2f", percent) + "%");
		}
		System.out.println("请选择要投票的选项");
		Scanner sc = new Scanner(System.in);
		Integer voteId = Integer.parseInt(sc.nextLine());// 得到的是选项的索引(第几个选项)
		Votes v = votes.get(voteId - 1);// 需要从集合中找到选项的id,再去操作数据库
		// 下面注释掉的这一段没有用事务的
		// voteDAO.updateVoteCount(v.getId());
		// subject.setVoteCnt(subject.getVoteCnt() + 1);
		// subjectDAO.updateSubject(subject);
		voteDAO.vote(v.getId(), id);// 进行投票，使用事务的投票
	}
}
