package com.company.test1;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.junit.Test;

public class RegexTest {
	@Test
	public void run(){
		String re="^[\u4e00-\u9fa5]{2,8}$";
		String nextLine=null;
		while(nextLine==null){
			Scanner sc=new Scanner(System.in);
			System.out.println("请输入姓名：");
			nextLine = sc.nextLine();
			Pattern compile = Pattern.compile(re);
			if(compile.matches(re, nextLine)){
				System.out.println("匹配");
			}else{
				System.out.println("不匹配");
				nextLine=null;
			}
		}
		
	}
	


}
