package com.company.domain;

public class Department {
	private int deparmentId;
	private String deparmentName;
	public Department() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Department(int deparmentId, String deparmentName) {
		super();
		this.deparmentId = deparmentId;
		this.deparmentName = deparmentName;
	}
	public int getDeparmentId() {
		return deparmentId;
	}
	public void setDeparmentId(int deparmentId) {
		this.deparmentId = deparmentId;
	}
	public String getDeparmentName() {
		return deparmentName;
	}
	public void setDeparmentName(String deparmentName) {
		this.deparmentName = deparmentName;
	}
	@Override
	public String toString() {
		return " [deparmentId=" + deparmentId + ", deparmentName=" + deparmentName + "]";
	}
	
	
}
