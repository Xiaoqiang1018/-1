package com.company.domain;

public class Staff {
	private int id;
	private String yuangongname;
	private String sex;
	private String indate;
	private String deparmentId;
	private String position;
	public Staff() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Staff(int id, String yuangongname, String sex, String indate, String deparmentId, String position) {
		
		this.id = id;
		this.yuangongname = yuangongname;
		this.sex = sex;
		this.indate = indate;
		this.deparmentId = deparmentId;
		this.position = position;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getYuangongname() {
		return yuangongname;
	}
	public void setYuangongname(String yuangongname) {
		this.yuangongname = yuangongname;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getIndate() {
		return indate;
	}
	public void setIndate(String indate) {
		this.indate = indate;
	}
	public String getDeparmentId() {
		return deparmentId;
	}
	public void setDeparmentId(String deparmentId) {
		this.deparmentId = deparmentId;
	}
	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		this.position = position;
	}
	@Override
	public String toString() {
		return " [id=" + id + ", yuangongname=" + yuangongname + ", sex=" + sex + ", indate=" + indate
				+ ", deparmentId=" + deparmentId + ", position=" + position + "]";
	}
	
	

}
