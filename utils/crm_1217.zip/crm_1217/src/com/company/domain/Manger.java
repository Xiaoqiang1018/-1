package com.company.domain;

public class Manger {
	private int deparmentId;
	private String deparmentName;
	private String position;
	public Manger() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Manger(int deparmentId, String deparmentName, String position) {
		
		this.deparmentId = deparmentId;
		this.deparmentName = deparmentName;
		this.position = position;
	}
	public int getDeparmentId() {
		return deparmentId;
	}
	public void setDeparmentId(int deparmentId) {
		this.deparmentId = deparmentId;
	}
	public String getDeparmentName() {
		return deparmentName;
	}
	public void setDeparmentName(String deparmentName) {
		this.deparmentName = deparmentName;
	}
	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		this.position = position;
	}
	@Override
	public String toString() {
		return " [deparmentId=" + deparmentId + ", deparmentName=" + deparmentName + ", position=" + position
				+ "]";
	}
	
	
}
