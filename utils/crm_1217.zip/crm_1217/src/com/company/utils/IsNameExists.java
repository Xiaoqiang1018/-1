package com.company.utils;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class IsNameExists {

	// 判断名字存不存在？
	public ResultSet check(String name) {
		String sql = "select id from staff where yuangongname=?";
		JdbcUtils ju = new JdbcUtils();
		List<Object> list = new ArrayList<Object>();
		if (name != null) {
			list.add(name);
		}
		ju.open();
		ResultSet resultSet = ju.query(sql, list);
		
		return resultSet;
	}

}
