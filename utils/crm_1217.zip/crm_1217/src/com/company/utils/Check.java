package com.company.utils;

import java.util.Scanner;
import java.util.regex.Pattern;

public class Check {

	public Boolean checkName(String name) {
		String re = "^[\u4e00-\u9fa5]{2,8}$";
		Boolean flag=false;
		Pattern compile = Pattern.compile(re);
		if (compile.matches(re, name)) {
			flag=true;
		} else {
			flag=false;
		}
		return flag;
	}

	

}