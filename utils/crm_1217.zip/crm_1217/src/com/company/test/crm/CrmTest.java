package com.company.test.crm;

import java.util.List;
import java.util.Scanner;

import org.junit.Test;

import com.company.dao.impl.StaffImpl;
import com.company.domain.Staff;

public class CrmTest {

	@Test
	public void CrmRun() {
		Scanner sc = new Scanner(System.in);

		Integer parseInt = null;
		while (parseInt == null) {
			System.out.println("请选择操作： 1 部门管理, 2 员工管理  3 职务管理");
			parseInt = Integer.parseInt(sc.nextLine());

			switch (parseInt) {
			case 1:
				System.out.println("a");
				break;
			case 2:
				CrmRun1();  //对员工表进行操作
				break;
			case 3:
				System.out.println("a");
				break;
			default:
				System.out.println("没有此操作");
				parseInt = null;
			}
		}

	}

	@Test
	public void CrmRun1() {
		Scanner sc = new Scanner(System.in);
		StaffImpl si = new StaffImpl();
		Integer parseInt = null;
		while (parseInt == null) {
			System.out.println("请选择你的操作：1 查询员工信息  2 增加用户信息  3 删除员工信息");
			parseInt = Integer.parseInt(sc.nextLine());

			switch (parseInt) {
			case 1:
				si.findAll(null,"老");
		
				break;
			case 2:
				si.add();
				si.findAll(null,null); //查看一下全部用户
				break;
			case 3:
				si.delete(2);
				si.findAll(null,null);
				break;
			default:
				System.out.println("没有此操作");
				parseInt = null;
			}
		}
	}

}
