package com.company.dao;

import java.util.List;

import com.company.domain.Staff;

public interface Search {
	
//	查询员工
	void findAll(Integer id, String name);
	

	
	//删除指定员工
	void delete(Integer id);
	
	
	//增加指定员工
	Integer add();

	
}
