package com.company.dao.impl;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.company.dao.Search;
import com.company.domain.Staff;
import com.company.utils.Check;
import com.company.utils.IsNameExists;
import com.company.utils.Check;
import com.company.utils.JdbcUtils;

public class StaffImpl implements Search{

	
	
//	按条件查找和按全部查找通过动态sql可以在一个方法中搞定
	@Override
	public  void findAll(Integer id,String name) {
		String sql="select * from staff where 1=1" ;
		List<Object> list = new ArrayList<Object>();
		if(id!= null){
			sql=sql+" and id=?";
			list.add(id);
		}
		if(name!=null){
			sql=sql+" and yuangongname like ?";
			list.add("%"+name+"%");
		}
		
		JdbcUtils ju = new JdbcUtils();
		ju.open();
		ResultSet resultSet = ju.query(sql, list);
		try {
			if(resultSet.next()){
				while(resultSet.next()){
					System.out.print(resultSet.getInt("id")+"\t");
					System.out.print(resultSet.getString("yuangongname")+"\t");
					System.out.print(resultSet.getString("sex")+"\t");
					System.out.print(resultSet.getString("indate")+"\t");
					System.out.print(resultSet.getString("deparmentId")+"\t");
					System.out.print(resultSet.getString("POSITION")+"\t");
					System.out.println();
				}
			}else{
				System.out.println("该用户不存在！");
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}finally{
			ju.close();
		}
		
			
			
		
		
		
		
	}

//	删除数据
	@Override
	public void delete(Integer id) {
		String sql="delete from staff where id=?";
		List<Object> list = new ArrayList<Object>();
		JdbcUtils ju = new JdbcUtils();
		
		list.add(id);
		ju.open();
		int queryUpdate = ju.queryUpdate(sql, list);
		System.out.println(queryUpdate+" 条数据被删除！");
		
		
			ju.close();
	
	}

	@Override
	public Integer add() {
		JdbcUtils ju = new JdbcUtils();
		String sql="insert into staff(yuangongname,sex,indate,deparmentId,position) "+
					"values(?,?,?,?,?);";
//		String regex_name=""
		Scanner sc=new Scanner(System.in);
		Check check = new Check();   //创建检查用户输入的信息合法性
		IsNameExists ine = new IsNameExists();  //检验名字是否存在
		List<Object> list = new ArrayList<Object>();
//		提示输入用户名，并检查用户名的合法性
		String name=null;
		while(name==null){
			System.out.print("请输入员工姓名：");
			name = sc.nextLine();
			try {
				if(check.checkName(name) && !ine.check(name).next()){   //检查姓名的合法性 ,并且检查用户名是否存在
					list.add(name);
				}else if(ine.check(name).next() && !check.checkName(name)){
					System.out.print("名字输入不正确！"+" ");
					name=null;
				}else if(ine.check(name).next() && check.checkName(name)){
					System.out.println("用户名已存在！");
					name=null;
				}else{
					System.out.println("用户名已存在！");
					name=null;
				}
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
		}
		
//		提示输入员工，并检查员工的正确性
		System.out.print("请输入员工性别：");
		list.add(sc.nextLine());
		System.out.print("请输入员工入职时间：");
		list.add(sc.nextLine());
		System.out.print("请输入员工名字部门id：");
		list.add(sc.nextLine());
		System.out.print("请输入员工名字职位：");
		list.add(sc.nextLine());
		int update = ju.queryUpdate(sql, list);
		return update;
	}




}
